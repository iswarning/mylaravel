#pragma once

int test_threads();
